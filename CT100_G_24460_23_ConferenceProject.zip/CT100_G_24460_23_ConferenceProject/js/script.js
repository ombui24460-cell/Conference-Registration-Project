// Student Technology & Innovation Conference registration logic.
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('registrationForm');
  if (!form) return;

  const byId = (id) => document.getElementById(id);
  const category = byId('category');
  const days = byId('days');
  const workshop = byId('workshop');
  const workshopField = byId('workshopField');
  const lunch = byId('lunch');
  const noLunch = byId('noLunch');
  const alertBox = byId('formAlert');

  const formatMoney = (amount) => 'KSh ' + Math.round(amount).toLocaleString('en-KE');

  function showWorkshop() {
    const needsWorkshop = category.value === 'workshop';
    workshopField.classList.toggle('hidden', !needsWorkshop);
    workshop.required = needsWorkshop;
    if (!needsWorkshop) workshop.value = '';
    calculateFee();
  }

  function calculateFee() {
    const selectedDays = Number(days.value) || 0;
    const registrationFee = 1000;
    const attendanceFee = selectedDays * 500;
    const workshopFee = category.value === 'workshop' ? 750 : 0;
    const mealFee = lunch.checked ? selectedDays * 300 : 0;
    const subtotal = registrationFee + attendanceFee + workshopFee + mealFee;
    const discount = selectedDays === 3 ? Math.round(subtotal * 0.10) : 0;
    const total = subtotal - discount;

    byId('registrationCost').textContent = formatMoney(registrationFee);
    byId('attendanceCost').textContent = formatMoney(attendanceFee);
    byId('workshopCost').textContent = formatMoney(workshopFee);
    byId('mealCost').textContent = formatMoney(mealFee);
    byId('discountCost').textContent = '− ' + formatMoney(discount);
    byId('discountLine').classList.toggle('hidden', discount === 0);
    byId('totalCost').textContent = formatMoney(total);

    let packageName = category.value === 'workshop' ? 'Workshop Participant' :
      category.value === 'conference' ? 'Conference Only' : 'Choose your options to build a package';
    if (selectedDays) packageName += category.value ? ` · ${selectedDays} day${selectedDays > 1 ? 's' : ''}` : '';
    byId('packageMessage').textContent = packageName;
  }

  function setError(id, message) {
    const error = byId(id + 'Error');
    if (error) error.textContent = message;
  }

  function validateForm() {
    let valid = true;
    alertBox.textContent = '';
    const name = byId('fullName').value.trim();
    const admission = byId('admission').value.trim();
    const email = byId('email').value.trim();
    const phone = byId('phone').value.trim();
    const year = byId('year').value;

    const checks = [
      ['fullName', name !== '', 'Enter your full name.'],
      ['admission', admission !== '', 'Enter your admission number.'],
      ['email', /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email), 'Enter a valid email address.'],
      ['phone', /^\d{10}$/.test(phone), 'Phone number must contain exactly 10 digits.'],
      ['year', year !== '', 'Select your year of study.'],
      ['category', category.value !== '', 'Select a participation category.'],
      ['days', ['1', '2', '3'].includes(days.value), 'Choose between 1 and 3 conference days.'],
      ['workshop', category.value !== 'workshop' || workshop.value !== '', 'Choose a workshop.']
    ];
    checks.forEach(([id, passed, message]) => {
      setError(id, passed ? '' : message);
      if (!passed) valid = false;
    });
    if (lunch.checked && noLunch.checked) {
      setError('meal', 'Choose either lunch or no catering, not both.');
      valid = false;
    } else {
      setError('meal', '');
    }
    if (!valid) {
      alertBox.textContent = 'Please correct the highlighted information before submitting.';
      const firstError = form.querySelector('.error:not(:empty)');
      if (firstError) firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    return valid;
  }

  category.addEventListener('change', showWorkshop);
  days.addEventListener('change', calculateFee);
  workshop.addEventListener('change', calculateFee);
  lunch.addEventListener('change', () => {
    if (lunch.checked) noLunch.checked = false;
    calculateFee();
  });
  noLunch.addEventListener('change', () => {
    if (noLunch.checked) lunch.checked = false;
    calculateFee();
  });
  form.querySelectorAll('input, select').forEach((control) => {
    control.addEventListener('input', () => {
      const error = byId(control.id + 'Error');
      if (error) error.textContent = '';
    });
  });
  form.addEventListener('submit', (event) => {
    if (!validateForm()) event.preventDefault();
  });

  showWorkshop();
  calculateFee();
});
