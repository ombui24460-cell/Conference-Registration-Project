<?php
declare(strict_types=1);
session_start();

function e(string $value): string {
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}
function post_string(string $key): string {
    return isset($_POST[$key]) && is_string($_POST[$key]) ? trim($_POST[$key]) : '';
}
function money(int $amount): string {
    return 'KSh ' . number_format($amount);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: register.html');
    exit;
}

$name = post_string('full_name');
$admission = post_string('admission_number');
$email = post_string('email');
$phone = post_string('phone');
$year = post_string('year_of_study');
$category = post_string('category');
$daysRaw = post_string('days');
$workshop = post_string('workshop');
$lunch = isset($_POST['lunch']) && $_POST['lunch'] === 'yes';
$errors = [];

if ($name === '') $errors[] = 'Full name is required.';
if ($admission === '') $errors[] = 'Admission number is required.';
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';
if (!preg_match('/^[0-9]{10}$/', $phone)) $errors[] = 'Phone number must contain exactly 10 digits.';
if ($year === '') $errors[] = 'Select your year of study.';
if (!in_array($category, ['conference', 'workshop'], true)) $errors[] = 'Select a participation category.';
$days = filter_var($daysRaw, FILTER_VALIDATE_INT);
if ($days === false || $days < 1 || $days > 3) $errors[] = 'Conference days must be between 1 and 3.';
if ($category === 'workshop' && $workshop === '') $errors[] = 'Select a workshop.';

if ($errors) {
    http_response_code(400);
    $pageTitle = 'Registration needs attention';
} else {
    $registrationFee = 1000;
    $attendanceFee = $days * 500;
    $workshopFee = $category === 'workshop' ? 750 : 0;
    $mealFee = $lunch ? $days * 300 : 0;
    $subtotal = $registrationFee + $attendanceFee + $workshopFee + $mealFee;
    // Individual requirement: registration number CT100/G/24460/23 ends in 0.
    $discount = $days === 3 ? (int) round($subtotal * 0.10) : 0;
    $total = max(0, $subtotal - $discount);
    $pageTitle = 'Registration successful';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= e($pageTitle) ?> | STI Conference</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header class="site-header"><div class="container nav-wrap"><a class="brand" href="index.html"><span class="brand-mark">ST</span><span>STI Conference</span></a><nav><a href="index.html">Home</a><a href="register.html">Register</a></nav></div></header>
<main class="confirmation-page"><div class="container narrow">
<?php if ($errors): ?>
  <div class="confirmation-card">
    <div class="confirmation-symbol error-symbol">!</div><p class="eyebrow">PLEASE CHECK YOUR DETAILS</p><h1>Registration not completed</h1>
    <p>Some information is missing or invalid. Return to the form and correct the following:</p>
    <ul class="error-list"><?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul>
    <a class="button button-primary" href="register.html">Return to registration</a>
  </div>
<?php else: ?>
  <div class="confirmation-card">
    <div class="confirmation-symbol">✓</div><p class="eyebrow">YOU'RE ON THE LIST</p><h1>Registration successful!</h1>
    <p class="confirmation-lead">Thank you, <?= e($name) ?>. Your conference registration has been received.</p>
    <div class="confirm-details">
      <div><span>Participant</span><strong><?= e($name) ?></strong></div>
      <div><span>Admission number</span><strong><?= e($admission) ?></strong></div>
      <div><span>Email address</span><strong><?= e($email) ?></strong></div>
      <div><span>Phone number</span><strong><?= e($phone) ?></strong></div>
      <div><span>Year of study</span><strong><?= e($year) ?></strong></div>
      <div><span>Participation</span><strong><?= $category === 'workshop' ? 'Workshop Participant' : 'Conference Only' ?></strong></div>
      <div><span>Conference days</span><strong><?= (int)$days ?></strong></div>
      <div><span>Workshop</span><strong><?= $category === 'workshop' ? e($workshop) : 'Not selected' ?></strong></div>
      <div><span>Lunch</span><strong><?= $lunch ? 'Yes' : 'No' ?></strong></div>
    </div>
    <div class="server-calculation"><p class="eyebrow">SERVER-CALCULATED FEE</p>
      <div class="calc-row"><span>Registration fee</span><strong><?= money($registrationFee) ?></strong></div>
      <div class="calc-row"><span>Attendance (<?= (int)$days ?> × KSh 500)</span><strong><?= money($attendanceFee) ?></strong></div>
      <div class="calc-row"><span>Workshop</span><strong><?= money($workshopFee) ?></strong></div>
      <div class="calc-row"><span>Lunch</span><strong><?= money($mealFee) ?></strong></div>
      <?php if ($discount > 0): ?><div class="calc-row discount-text"><span>3-day discount (10%)</span><strong>− <?= money($discount) ?></strong></div><?php endif; ?>
      <div class="server-total"><span>Total amount payable</span><strong><?= money($total) ?></strong></div>
    </div>
    <p class="thanks">We look forward to welcoming you to the Student Technology &amp; Innovation Conference.</p>
    <div class="confirm-actions"><a class="button button-primary" href="index.html">Back to home</a><button class="button button-outline" onclick="window.print()" type="button">Print confirmation</button></div>
  </div>
<?php endif; ?>
</div></main>
<footer><div class="container footer-wrap"><span>© 2026 Student Technology &amp; Innovation Conference</span><span>Registration confirmation</span></div></footer>
</body>
</html>
